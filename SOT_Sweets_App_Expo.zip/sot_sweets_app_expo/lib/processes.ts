export type ProcessKey =
  | 'arrival' | 'oven_dry' | 'roast' | 'winnower' | 'press'
  | 'powder_grind' | 'choc_milling' | 'temper_mold' | 'packaging';

type FieldDef = { key:string; label:string; type?: 'text'|'number'|'select'; hint?:string; options?:string[] };

export const PROCESS_LABEL: Record<ProcessKey,string> = {
  arrival:'Arrival', oven_dry:'Oven Drying', roast:'Roasting', winnower:'Winnower',
  press:'Oil Pressing', powder_grind:'Cacao Powder Grinding', choc_milling:'Chocolate Milling',
  temper_mold:'Tempering & Molding', packaging:'Packaging'
};

export const PROCESS_FIELDS: Record<ProcessKey, FieldDef[]> = {
  arrival: [
    { key:'batch_number', label:'Batch Number' },
    { key:'kg', label:'Kg', type:'number' },
    { key:'moist', label:'Moist (%)', type:'number' },
    { key:'date', label:'Date' },
    { key:'price', label:'Price' },
    { key:'inspection', label:'Visible inspection (1-10)', type:'number' },
  ],
  oven_dry: [
    { key:'batch_number', label:'Batch Number' },
    { key:'temp', label:'Temp (°C)', type:'number' },
    { key:'duration', label:'Duration (min)', type:'number' },
    { key:'kg_in', label:'Kg in', type:'number' },
    { key:'kg_out', label:'Kg out', type:'number' },
    { key:'moist_in', label:'Moist in (%)', type:'number' },
    { key:'moist_out', label:'Moist out (%)', type:'number' },
    { key:'datetime', label:'Date & Time' },
  ],
  roast: [
    { key:'batch_number', label:'Batch Number' },
    { key:'temp', label:'Temp (°C)', type:'number' },
    { key:'duration', label:'Duration (min)', type:'number' },
    { key:'kg_in', label:'Kg in', type:'number' },
    { key:'kg_out', label:'Kg out', type:'number' },
    { key:'moist_in', label:'Moist in (%)', type:'number' },
    { key:'moist_out', label:'Moist out (%)', type:'number' },
    { key:'datetime', label:'Date & Time' },
  ],
  winnower: [
    { key:'batch_number', label:'Batch Number' },
    { key:'duration', label:'Duration (min)', type:'number' },
    { key:'kg_in', label:'Kg in', type:'number' },
    { key:'kg_out', label:'Kg out', type:'number' },
    { key:'datetime', label:'Date & Time' },
  ],
  press: [
    { key:'batch_number', label:'Batch Number' },
    { key:'duration', label:'Duration (min)', type:'number' },
    { key:'kg_nibs_in', label:'Kg nibs in', type:'number' },
    { key:'kg_butter_out', label:'Kg cacao butter out', type:'number' },
    { key:'kg_solids_out', label:'Kg cacao solids out', type:'number' },
  ],
  powder_grind: [
    { key:'batch_number', label:'Batch Number' },
    { key:'duration', label:'Duration (min)', type:'number' },
    { key:'kg_in', label:'Kg in', type:'number' },
    { key:'kg_out', label:'Kg out', type:'number' },
    { key:'date', label:'Date' },
  ],
  choc_milling: [
    { key:'batch_number', label:'Batch Number' },
    { key:'choc_type', label:'Chocolate type', type:'select', options:['White','Dark','Milk','Espresso'] },
    { key:'mill', label:'Chocolate mill', type:'select', options:['Ballmill','Stonegrinder'] },
    { key:'ingredients', label:'Ingredients (JSON or notes)' },
    { key:'sessions', label:'Milling sessions (clock-in/out lines)' },
  ],
  temper_mold: [
    { key:'batch_number', label:'Batch Number' },
    { key:'date', label:'Date' },
    { key:'choc_type', label:'Chocolate type' },
    { key:'kg_in', label:'Chocolate kg in', type:'number' },
    { key:'duration', label:'Tempering duration (min)', type:'number' },
    { key:'temp_heat', label:'Heating temp (°C)', type:'number' },
    { key:'temp_cool', label:'Cooling temp (°C)', type:'number' },
    { key:'molding_100g', label:'Molding: pieces 100g', type:'number' },
    { key:'molding_33g', label:'Molding: pieces 33g', type:'number' },
    { key:'cool_temp', label:'Cooling temperature (°C)', type:'number' },
    { key:'cool_time', label:'Cooling time (min)', type:'number' },
    { key:'packaging_date', label:'Packaging date' },
    { key:'packaging_code', label:'Packaging code' },
  ],
  packaging: [
    { key:'batch_number', label:'Batch Number' },
    { key:'date', label:'Date' },
    { key:'code', label:'Packaging code' },
  ],
};

export function totalMillingMinutes(sessions: string): number {
  const lines = (sessions || '').split(/\n|,/).map(x => x.trim()).filter(Boolean);
  let total = 0;
  for (const line of lines) {
    const m = line.match(/(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})/);
    if (!m) continue;
    const h1 = parseInt(m[1],10), m1 = parseInt(m[2],10);
    const h2 = parseInt(m[3],10), m2 = parseInt(m[4],10);
    total += (h2*60 + m2) - (h1*60 + m1);
  }
  return total;
}
