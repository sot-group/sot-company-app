export type ProcessType =
  | 'arrival'
  | 'drying'
  | 'roasting'
  | 'winnowing'
  | 'pressing'
  | 'powder_grinding'
  | 'choc_milling'
  | 'tempering_molding'
  | 'packaging';

export type Batch = {
  id?: number;
  batch_code: string;
  process_type: ProcessType;
  fields_json: any;
  status?: 'draft' | 'synced';
  notes?: string;
  created_by?: string;
  created_at?: string;
  updated_at?: string;
};

export type BatchInput = { child_batch_id: number; parent_batch_id: number; };