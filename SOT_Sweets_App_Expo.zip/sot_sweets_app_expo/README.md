# S.O.T. — Sweets of Timor (Expo App)
Offline-first batch logging with WordPress REST sync.

## Quick start
1) Install Node LTS.
2) In this folder: `npm install`
3) `npm run start` → open in Expo Go (iOS) or run a simulator.
4) Go to **Settings** tab and enter:
   - Base URL: https://shop.oftimor.com
   - Username: your WP username (with Application Password)
   - Password: that Application Password
5) Create batches in **New Entry** (paste your process fields as JSON).
6) Find it in **Search** and press **Sync to WP**.

Tables: `batches`, `batch_inputs`, `outbox` (reserved for queued sync).