import * as SQLite from 'expo-sqlite';

// Lazily open & initialize once
let dbPromise: Promise<any> | null = null;

async function ensureDb() {
  if (!dbPromise) {
    dbPromise = (async () => {
      // Open using the async API available in SDK 53+
      const d: any = await (SQLite as any).openDatabaseAsync('sot_sweets.db');

      // Basic init
      if (d.execAsync) {
        await d.execAsync('PRAGMA foreign_keys = ON;');
        await d.execAsync(`CREATE TABLE IF NOT EXISTS batches (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          batch_code TEXT UNIQUE,
          process_type TEXT,
          fields_json TEXT,
          notes TEXT,
          created_at TEXT,
          updated_at TEXT
        );`);
        await d.execAsync(`CREATE UNIQUE INDEX IF NOT EXISTS idx_batches_code ON batches(batch_code);`);
        await d.execAsync(`CREATE TABLE IF NOT EXISTS batch_inputs (
          child_batch_id INTEGER,
          parent_batch_id INTEGER
        );`);
      }
      return d;
    })();
  }
  return dbPromise!;
}

export async function initDb() {
  await ensureDb();
}

export const nowIso = () => new Date().toISOString();

// ---- helpers ---------------------------------------------------------------

export async function run(sql: string, ...params: any[]) {
  const d: any = await ensureDb();
  if (d.runAsync) return d.runAsync(sql, params);
  if (d.prepareAsync) {
    const stmt = await d.prepareAsync(sql);
    try { await stmt.executeAsync(params); }
    finally { await stmt.finalizeAsync?.(); }
    return;
  }
  // Last resort (no params support)
  if (d.execAsync) return d.execAsync(sql);
  throw new Error('SQLite driver missing runAsync/prepareAsync/execAsync');
}

export async function getAll<T = any>(sql: string, ...params: any[]): Promise<T[]> {
  const d: any = await ensureDb();
  if (d.getAllAsync) return d.getAllAsync(sql, params);
  if (d.prepareAsync) {
    const stmt = await d.prepareAsync(sql);
    try { return await stmt.getAllAsync(params); }
    finally { await stmt.finalizeAsync?.(); }
  }
  throw new Error('SQLite driver missing getAllAsync/prepareAsync');
}

export async function getFirst<T = any>(sql: string, ...params: any[]): Promise<T | undefined> {
  const d: any = await ensureDb();
  if (d.getFirstAsync) return d.getFirstAsync(sql, params);
  if (d.prepareAsync) {
    const stmt = await d.prepareAsync(sql);
    try { return await stmt.getFirstAsync(params); }
    finally { await stmt.finalizeAsync?.(); }
  }
  const all = await getAll<T>(sql, ...params);
  return all[0];
}
