import * as SecureStore from 'expo-secure-store';
import { encode as btoa } from 'base-64';

type Creds = { base:string; user:string; pass:string };

export async function getWpCreds(): Promise<Creds> {
  const base = (await SecureStore.getItemAsync('wpBase')) || '';
  const user = (await SecureStore.getItemAsync('wpUser')) || '';
  const pass = (await SecureStore.getItemAsync('wpPass')) || '';
  if (!base || !user || !pass) throw new Error('Missing WP settings. Set Base/Username/Password in the app Settings.');
  return { base: base.replace(/\/+$/,''), user, pass };
}

export async function postBatch(body: any) {
  const { base, user, pass } = await getWpCreds();
  const res = await fetch(`${base}/wp-json/sot/v1/batch`, {
    method: 'POST',
    headers: {
      'Authorization': `Basic ${btoa(`${user}:${pass}`)}`,
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  let json: any;
  try { json = JSON.parse(text); } catch { json = { raw: text }; }
  if (!res.ok) {
    const msg = json?.error || json?.message || `HTTP ${res.status}`;
    throw new Error(`WP sync failed: ${msg}`);
  }
  return json;
}
