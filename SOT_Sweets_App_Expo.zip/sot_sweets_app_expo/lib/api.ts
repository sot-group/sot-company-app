import axios from 'axios';
import * as SecureStore from 'expo-secure-store';
import { encode as btoa } from 'base-64';

type Creds = { baseUrl: string; username: string; password: string };

export async function saveCreds(c: Creds) {
  await SecureStore.setItemAsync('api_creds', JSON.stringify(c));
}
export async function getCreds(): Promise<Creds | null> {
  const v = await SecureStore.getItemAsync('api_creds');
  return v ? JSON.parse(v) : null;
}

export async function apiClient() {
  const creds = await getCreds();
  if (!creds) throw new Error('Missing API credentials');
  const { baseUrl, username, password } = creds;
  const inst = axios.create({
    baseURL: baseUrl.replace(/\/$/, ''),
    headers: {
      'Authorization': 'Basic ' + btoa(`${username}:${password}`),
      'Content-Type': 'application/json'
    },
    timeout: 15000
  });
  return inst;
}

export async function createBatch(payload: any) {
  const client = await apiClient();
  const { data } = await client.post('/wp-json/sot/v1/batch', payload);
  return data;
}

export async function updateBatch(id: number, payload: any) {
  const client = await apiClient();
  const { data } = await client.put(`/wp-json/sot/v1/batch/${id}`, payload);
  return data;
}

export async function fetchBatchByCode(code: string) {
  const client = await apiClient();
  const { data } = await client.get('/wp-json/sot/v1/batch', { params: { batch_code: code }});
  return data;
}