import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet, ScrollView, Alert } from 'react-native';
import { db } from '../lib/db';
import { useLocalSearchParams } from 'expo-router';
import { createBatch } from '../lib/api';

export default function SearchScreen() {
  const [code, setCode] = useState('');
  const [record, setRecord] = useState<any>(null);
  const params = useLocalSearchParams<{code?: string}>();

  useEffect(() => {
    if (params?.code) { setCode(String(params.code)); onSearch(String(params.code)); }
  }, [params]);

  const onSearch = (c?: string) => {
    const r = db.getFirstSync('SELECT * FROM batches WHERE batch_code = ?', (c ?? code).trim());
    setRecord(r || null);
  };

  const sync = async () => {
    if (!record) return;
    try {
      const parents = db.getAllSync('SELECT parent_batch_id FROM batch_inputs WHERE child_batch_id = ?', record.id) as any[];
      const parentCodes = parents.map(p => db.getFirstSync('SELECT batch_code FROM batches WHERE id = ?', p.parent_batch_id)?.batch_code).filter(Boolean);
      const payload = {
        batch_code: record.batch_code,
        process_type: record.process_type,
        fields: JSON.parse(record.fields_json || '{}'),
        notes: record.notes,
        parent_batch_codes: parentCodes
      };
      await createBatch(payload);
      Alert.alert('Synced to WordPress');
    } catch (e: any) {
      Alert.alert('Sync error', e.message);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 16 }}>
      <Text style={styles.title}>Search</Text>
      <TextInput style={styles.input} placeholder="Batch Code" value={code} onChangeText={setCode} autoCapitalize="characters" />
      <Pressable style={styles.btn} onPress={() => onSearch()}><Text>Find</Text></Pressable>
      {record && (
        <View style={styles.card}>
          <Text style={styles.h2}>{record.batch_code}</Text>
          <Text style={styles.kv}>Process: {record.process_type}</Text>
          <Text style={styles.kv}>Fields: {record.fields_json}</Text>
          <Text style={styles.kv}>Notes: {record.notes || '-'}</Text>
          <Pressable style={[styles.btn, { backgroundColor: '#c1ff72' }]} onPress={sync}><Text>Sync to WP</Text></Pressable>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0c0c0c' },
  title: { color: '#f6c453', fontSize: 20, fontWeight: '800', marginBottom: 12 },
  input: { backgroundColor: '#fff', padding: 10, borderRadius: 8, marginBottom: 10 },
  btn: { backgroundColor: '#f6c453', padding: 12, borderRadius: 8, alignItems: 'center', marginBottom: 10 },
  card: { backgroundColor: '#1a1a1a', padding: 12, borderRadius: 12, borderColor: '#333', borderWidth: 1 },
  h2: { color: '#fff', fontSize: 18, fontWeight: '800', marginBottom: 8 },
  kv: { color: '#ddd', marginBottom: 6 }
});