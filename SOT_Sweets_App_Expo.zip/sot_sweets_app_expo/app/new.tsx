import React, { useState } from 'react';
import { Text, TextInput, Pressable, StyleSheet, ScrollView, Alert } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { db, nowIso } from '../lib/db';

const processLabels: any = {
  arrival: 'Arrival',
  drying: 'Oven Drying',
  roasting: 'Roasting',
  winnowing: 'Winnowing',
  pressing: 'Oil Pressing',
  powder_grinding: 'Cacao Powder Grinding',
  choc_milling: 'Chocolate Milling',
  tempering_molding: 'Tempering & Molding',
  packaging: 'Packaging'
};

export default function NewEntry() {
  const { type } = useLocalSearchParams<{ type?: string }>();
  const router = useRouter();
  const [batchCode, setBatchCode] = useState('');
  const [notes, setNotes] = useState('');
  const [jsonText, setJsonText] = useState('{}');
  const [parentBatchCodes, setParentBatchCodes] = useState(''); // comma-separated

  const save = () => {
    try {
      const fields = JSON.parse(jsonText || '{}');
      const t = nowIso();
      db.runSync(
        'INSERT INTO batches (batch_code, process_type, fields_json, notes, created_at, updated_at) VALUES (?,?,?,?,?,?)',
        batchCode.trim(), String(type), JSON.stringify(fields), notes, t, t
      );
      const res = db.getFirstSync('SELECT id FROM batches WHERE batch_code = ?', batchCode.trim());
      if (res?.id) {
        const list = parentBatchCodes.split(',').map(s => s.trim()).filter(Boolean);
        for (const code of list) {
          const parent = db.getFirstSync('SELECT id FROM batches WHERE batch_code = ?', code);
          if (parent?.id) {
            db.runSync('INSERT INTO batch_inputs (child_batch_id, parent_batch_id) VALUES (?,?)', res.id, parent.id);
          }
        }
      }
      Alert.alert('Saved locally');
      router.replace(`/search?code=${encodeURIComponent(batchCode)}`);
    } catch (e: any) {
      Alert.alert('Error', e.message);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 16 }}>
      <Text style={styles.title}>New {processLabels[type as string] || 'Entry'}</Text>
      <TextInput style={styles.input} placeholder="Batch Code (unique)" value={batchCode} onChangeText={setBatchCode} autoCapitalize="characters" />
      <TextInput style={styles.input} placeholder="Parent Batch Codes (comma separated)" value={parentBatchCodes} onChangeText={setParentBatchCodes} />
      <Text style={styles.label}>Fields JSON (paste key/values for this process)</Text>
      <TextInput style={[styles.input, { height: 140 }]} multiline value={jsonText} onChangeText={setJsonText} />
      <TextInput style={styles.input} placeholder="Notes" value={notes} onChangeText={setNotes} />
      <Pressable style={styles.btn} onPress={save}><Text style={{ fontWeight: '800' }}>Save Draft</Text></Pressable>
      <Text style={{ color: '#888', marginTop: 8 }}>Tip: enter fields like {"{kg_in:10,kg_out:9,temp_c:120}"}</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0c0c0c' },
  title: { color: '#f6c453', fontSize: 20, fontWeight: '800', marginBottom: 12 },
  input: { backgroundColor: '#fff', padding: 10, borderRadius: 8, marginBottom: 10 },
  label: { color: '#ddd', marginBottom: 6 },
  btn: { backgroundColor: '#f6c453', padding: 14, borderRadius: 10, alignItems: 'center', marginTop: 8 }
});