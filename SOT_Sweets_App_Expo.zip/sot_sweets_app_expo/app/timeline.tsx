import React, { useState } from 'react';
import { Text, TextInput, Pressable, StyleSheet, ScrollView } from 'react-native';
import { db } from '../lib/db';

export default function TimelineScreen() {
  const [code, setCode] = useState('');
  const [lines, setLines] = useState<string[]>([]);

  const build = (startCode: string) => {
    const start = db.getFirstSync('SELECT * FROM batches WHERE batch_code = ?', startCode.trim());
    if (!start) { setLines(['Batch not found']); return; }
    const out: string[] = [];
    const visit = (id: number, depth: number) => {
      const rec = db.getFirstSync('SELECT * FROM batches WHERE id = ?', id);
      if (!rec) return;
      out.push(`${'  '.repeat(depth)}• ${rec.batch_code} (${rec.process_type})`);
      const parents = db.getAllSync('SELECT parent_batch_id FROM batch_inputs WHERE child_batch_id = ?', id) as any[];
      for (const p of parents) visit(p.parent_batch_id, depth + 1);
    };
    visit(start.id, 0);
    setLines(out);
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 16 }}>
      <Text style={styles.title}>Batch Timeline</Text>
      <TextInput style={styles.input} placeholder="Enter batch code" value={code} onChangeText={setCode} />
      <Pressable style={styles.btn} onPress={() => build(code)}><Text>Build</Text></Pressable>
      {lines.map((l, i) => <Text key={i} style={{ color: '#ddd', fontFamily: 'Menlo' }}>{l}</Text>)}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0c0c0c' },
  title: { color: '#f6c453', fontSize: 20, fontWeight: '800', marginBottom: 12 },
  input: { backgroundColor: '#fff', padding: 10, borderRadius: 8, marginBottom: 10 },
  btn: { backgroundColor: '#f6c453', padding: 12, borderRadius: 8, alignItems: 'center', marginBottom: 10 }
});